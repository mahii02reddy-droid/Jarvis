package com.mahesh.jarvis;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Opens a WhatsApp chat with the text pre-filled and taps the Send button. */
public class JarvisAccessibilityService extends AccessibilityService {
    static volatile JarvisAccessibilityService inst;
    static volatile long pendingUntil = 0;
    static final AtomicBoolean sent = new AtomicBoolean(false);

    @Override protected void onServiceConnected() { inst = this; }

    @Override public boolean onUnbind(Intent i) { inst = null; return super.onUnbind(i); }

    @Override public void onInterrupt() {}

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (System.currentTimeMillis() > pendingUntil) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        if (trySend(root)) {
            sent.set(true);
            pendingUntil = 0;
        }
    }

    private boolean trySend(AccessibilityNodeInfo root) {
        String[] ids = {"com.whatsapp:id/send", "com.whatsapp.w4b:id/send"};
        for (String id : ids) {
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(id);
            if (l != null) for (AccessibilityNodeInfo n : l) if (click(n)) return true;
        }
        List<AccessibilityNodeInfo> byText = root.findAccessibilityNodeInfosByText("Send");
        if (byText != null) {
            for (AccessibilityNodeInfo n : byText) {
                CharSequence d = n.getContentDescription();
                if (d != null && d.toString().equalsIgnoreCase("Send") && click(n)) return true;
            }
        }
        return false;
    }

    private boolean click(AccessibilityNodeInfo n) {
        while (n != null) {
            if (n.isClickable() && n.isEnabled()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            n = n.getParent();
        }
        return false;
    }

    /** Wake the screen and open wa.me chat. Returns false if the service is not enabled. */
    @SuppressWarnings("deprecation")
    static boolean open(Context ctx, String number, String text) {
        JarvisAccessibilityService s = inst;
        if (s == null) return false;
        sent.set(false);
        pendingUntil = System.currentTimeMillis() + 25000;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "jarvis:wake");
        wl.acquire(8000);
        Uri u = Uri.parse("https://wa.me/" + number + "?text=" + Uri.encode(text));
        String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b", null};
        for (String p : pkgs) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (p != null) i.setPackage(p);
                s.startActivity(i);
                return true;
            } catch (Exception ignored) {}
        }
        return false;
    }
}
