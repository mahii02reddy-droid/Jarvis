package com.mahesh.jarvis;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "jarvis/native";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    switch (call.method) {
                        case "startService":
                            startForegroundService(new Intent(this, JarvisService.class));
                            result.success(true);
                            break;
                        case "stopService":
                            stopService(new Intent(this, JarvisService.class));
                            result.success(true);
                            break;
                        case "beep":
                            new ToneGenerator(AudioManager.STREAM_MUSIC, 80)
                                    .startTone(ToneGenerator.TONE_PROP_BEEP, 150);
                            result.success(true);
                            break;
                        case "isLocked":
                            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                            result.success(km.isKeyguardLocked());
                            break;
                        case "openWhatsApp":
                            result.success(JarvisAccessibilityService.open(
                                    getApplicationContext(),
                                    call.argument("number"), call.argument("text")));
                            break;
                        case "consumeSent":
                            result.success(JarvisAccessibilityService.sent.getAndSet(false));
                            break;
                        case "isAccessibilityEnabled":
                            result.success(JarvisAccessibilityService.inst != null);
                            break;
                        case "canDrawOverlays":
                            result.success(Settings.canDrawOverlays(this));
                            break;
                        case "isBatteryUnrestricted":
                            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                            result.success(pm.isIgnoringBatteryOptimizations(getPackageName()));
                            break;
                        case "openAccessibilitySettings":
                            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                            result.success(true);
                            break;
                        case "openOverlaySettings":
                            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName())));
                            result.success(true);
                            break;
                        case "openBatterySettings":
                            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    Uri.parse("package:" + getPackageName())));
                            result.success(true);
                            break;
                        default:
                            result.notImplemented();
                    }
                });
    }
}
