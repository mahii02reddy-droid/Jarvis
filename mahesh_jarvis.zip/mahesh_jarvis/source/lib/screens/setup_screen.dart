import 'dart:async';
import 'dart:convert';

import 'package:eagle_flutter/eagle_profiler.dart';
import 'package:flutter/material.dart';
import 'package:flutter_voice_processor/flutter_voice_processor.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/native.dart';
import '../services/settings.dart';
import '../services/voice_pipeline.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> with WidgetsBindingObserver {
  final s = Settings.i;
  late final pico = TextEditingController(text: s.str('pico'));
  late final claude = TextEditingController(text: s.str('claude'));
  late final cc = TextEditingController(text: s.str('cc', '91'));

  bool mic = false, contacts = false, notif = false, access = false, overlay = false, battery = false;
  bool enrolling = false;
  double pct = 0;
  String enrolMsg = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    mic = await Permission.microphone.isGranted;
    contacts = await Permission.contacts.isGranted;
    notif = await Permission.notification.isGranted;
    access = await Native.accessibilityOn();
    overlay = await Native.overlayOn();
    battery = await Native.batteryOk();
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    await s.set('pico', pico.text.trim());
    await s.set('claude', claude.text.trim());
    await s.set('cc', cc.text.trim());
  }

  Widget _perm(String title, String sub, bool ok, VoidCallback onGrant) => ListTile(
        dense: true,
        leading: Icon(ok ? Icons.check_circle : Icons.error_outline,
            color: ok ? Colors.greenAccent : Colors.orangeAccent),
        title: Text(title),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
        trailing: ok ? null : FilledButton.tonal(onPressed: onGrant, child: const Text('Grant')),
      );

  Future<void> _enrol() async {
    await _save();
    if (s.str('pico').isEmpty) {
      setState(() => enrolMsg = 'Enter your Picovoice AccessKey first');
      return;
    }
    if (!mic) await Permission.microphone.request();
    await VoicePipeline.i.stop();
    setState(() {
      enrolling = true;
      pct = 0;
      enrolMsg = 'Speak normally for about 30 seconds (read anything aloud)…';
    });
    final vp = VoiceProcessor.instance;
    EagleProfiler? p;
    void Function(List<int>)? listener;
    try {
      p = await EagleProfiler.create(s.str('pico'));
      final min = await p.minEnrollSamples();
      final buf = <int>[];
      var busy = false;
      final done = Completer<void>();
      listener = (List<int> f) async {
        if (busy || done.isCompleted) return;
        buf.addAll(f);
        if (buf.length < min) return;
        busy = true;
        final chunk = buf.sublist(0, min);
        buf.removeRange(0, min);
        try {
          final r = await p!.enroll(chunk);
          if (mounted) setState(() => pct = r.percentage.toDouble());
          if (r.percentage >= 100 && !done.isCompleted) done.complete();
        } catch (e) {
          if (!done.isCompleted) done.completeError(e);
        }
        busy = false;
      };
      vp.addFrameListener(listener);
      await vp.start(512, p.sampleRate);
      await done.future.timeout(const Duration(minutes: 3));
      await vp.stop();
      final profile = await p.export();
      await s.set('profile', base64Encode(profile.bytes));
      enrolMsg = 'Voice saved. Jarvis will now only obey you.';
    } catch (e) {
      try {
        await vp.stop();
      } catch (_) {}
      enrolMsg = 'Enrolment failed: $e';
    } finally {
      if (listener != null) vp.removeFrameListener(listener);
      await p?.delete();
      if (mounted) setState(() => enrolling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final enrolled = s.str('profile').isNotEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('Setup')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('1. Keys', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          TextField(
            controller: pico,
            decoration: const InputDecoration(
                labelText: 'Picovoice AccessKey (required)', border: OutlineInputBorder()),
            onChanged: (_) => _save(),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: claude,
            obscureText: true,
            decoration: const InputDecoration(
                labelText: 'Claude API key (optional, smarter commands)',
                border: OutlineInputBorder()),
            onChanged: (_) => _save(),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextField(
                controller: cc,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Country code', border: OutlineInputBorder()),
                onChanged: (_) => _save(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: s.str('locale', 'en_IN'),
                decoration: const InputDecoration(
                    labelText: 'Speech language', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'en_IN', child: Text('English (India)')),
                  DropdownMenuItem(value: 'hi_IN', child: Text('Hindi')),
                  DropdownMenuItem(value: 'te_IN', child: Text('Telugu')),
                ],
                onChanged: (v) => s.set('locale', v ?? 'en_IN'),
              ),
            ),
          ]),
          const Divider(height: 32),
          Text('2. Permissions', style: Theme.of(context).textTheme.titleMedium),
          _perm('Microphone', 'Needed to hear "Jarvis"', mic,
              () async { await Permission.microphone.request(); _refresh(); }),
          _perm('Contacts', 'To find who to message', contacts,
              () async { await Permission.contacts.request(); _refresh(); }),
          _perm('Notifications', 'Shows the "listening" notification', notif,
              () async { await Permission.notification.request(); _refresh(); }),
          _perm('Accessibility', 'Lets Jarvis tap Send in WhatsApp', access, Native.openAccessibility),
          _perm('Display over other apps', 'Lets Jarvis open WhatsApp from the background',
              overlay, Native.openOverlay),
          _perm('Battery: Unrestricted', 'Stops Android from killing Jarvis', battery, Native.openBattery),
          const Divider(height: 32),
          Text('3. Only my voice', style: Theme.of(context).textTheme.titleMedium),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Only obey my voice'),
            value: s.b('voiceOnly', true),
            onChanged: (v) async { await s.set('voiceOnly', v); setState(() {}); },
          ),
          Text('Match strictness: ${s.d('threshold', 0.5).toStringAsFixed(2)} '
              '(raise if others can trigger it, lower if it ignores you)',
              style: const TextStyle(fontSize: 12)),
          Slider(
            min: 0.2,
            max: 0.9,
            value: s.d('threshold', 0.5),
            onChanged: (v) async { await s.set('threshold', v); setState(() {}); },
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: enrolling ? null : _enrol,
            icon: const Icon(Icons.record_voice_over),
            label: Text(enrolled ? 'Re-record my voice' : 'Record my voice'),
          ),
          if (enrolling) ...[
            const SizedBox(height: 12),
            LinearProgressIndicator(value: pct / 100),
          ],
          if (enrolMsg.isNotEmpty)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text(enrolMsg)),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
