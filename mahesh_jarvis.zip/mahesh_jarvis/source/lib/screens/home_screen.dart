import 'package:flutter/material.dart';
import '../services/voice_pipeline.dart';
import 'setup_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final p = VoicePipeline.i;

  Future<void> _toggle() async {
    if (p.running) {
      await p.stop();
    } else {
      await p.start();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mahesh's Jarvis"),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SetupScreen())),
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 32),
          GestureDetector(
            onTap: _toggle,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: p.running ? cs.primary : cs.surfaceContainerHighest,
                boxShadow: p.running
                    ? [BoxShadow(color: cs.primary.withOpacity(.5), blurRadius: 30)]
                    : null,
              ),
              child: Icon(p.running ? Icons.mic : Icons.mic_off,
                  size: 64, color: p.running ? cs.onPrimary : cs.onSurface),
            ),
          ),
          const SizedBox(height: 16),
          ValueListenableBuilder<String>(
            valueListenable: p.status,
            builder: (_, s, __) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(s,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium),
            ),
          ),
          const SizedBox(height: 4),
          Text(p.running ? 'Tap to stop' : 'Tap to start',
              style: Theme.of(context).textTheme.bodySmall),
          const Divider(height: 32),
          Expanded(
            child: ValueListenableBuilder<List<String>>(
              valueListenable: p.logs,
              builder: (_, l, __) => ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: l.length,
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(l[i], style: const TextStyle(fontSize: 12.5)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
