import 'package:flutter/services.dart';

/// Bridge to the Java code in android/ (service, accessibility, lock state).
class Native {
  static const _c = MethodChannel('jarvis/native');
  static Future<bool> _b(String m, [Object? a]) async =>
      (await _c.invokeMethod<bool>(m, a)) ?? false;

  static Future<void> startService() => _c.invokeMethod('startService');
  static Future<void> stopService() => _c.invokeMethod('stopService');
  static Future<void> beep() => _c.invokeMethod('beep');

  static Future<bool> isLocked() => _b('isLocked');
  static Future<bool> consumeSent() => _b('consumeSent');
  static Future<bool> openWhatsApp(String number, String text) =>
      _b('openWhatsApp', {'number': number, 'text': text});

  static Future<bool> accessibilityOn() => _b('isAccessibilityEnabled');
  static Future<bool> overlayOn() => _b('canDrawOverlays');
  static Future<bool> batteryOk() => _b('isBatteryUnrestricted');
  static Future<void> openAccessibility() => _c.invokeMethod('openAccessibilitySettings');
  static Future<void> openOverlay() => _c.invokeMethod('openOverlaySettings');
  static Future<void> openBattery() => _c.invokeMethod('openBatterySettings');
}
