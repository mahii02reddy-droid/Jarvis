import 'package:shared_preferences/shared_preferences.dart';

class Settings {
  Settings._();
  static final Settings i = Settings._();
  late SharedPreferences _p;

  Future<void> load() async => _p = await SharedPreferences.getInstance();

  String str(String k, [String d = '']) => _p.getString(k) ?? d;
  bool b(String k, [bool d = false]) => _p.getBool(k) ?? d;
  double d(String k, [double def = 0]) => _p.getDouble(k) ?? def;

  Future<void> set(String k, Object v) async {
    if (v is String) await _p.setString(k, v);
    if (v is bool) await _p.setBool(k, v);
    if (v is double) await _p.setDouble(k, v);
  }

  Future<void> remove(String k) => _p.remove(k);
}
