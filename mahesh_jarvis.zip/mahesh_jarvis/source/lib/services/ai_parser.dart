import 'dart:convert';
import 'package:http/http.dart' as http;
import 'settings.dart';

class Command {
  final String action; // whatsapp | reply
  final String? contact, message, reply;
  Command(this.action, {this.contact, this.message, this.reply});
}

class AiParser {
  static const _system = '''
You convert one spoken voice command (English, Hindi, Telugu or mixed, maybe transliterated) into JSON only. No prose, no code fences.
If the user wants to send a WhatsApp message return:
{"action":"whatsapp","contact":"<contact name in Latin letters>","message":"<message text to send, in the language dictated, cleaned up>"}
Otherwise return:
{"action":"reply","text":"<short helpful answer under 25 words>"}''';

  static Future<Command> parse(String text) async {
    final key = Settings.i.str('claude');
    if (key.isNotEmpty) {
      try {
        return await _claude(text, key);
      } catch (_) {/* fall back to local rules */}
    }
    return _local(text);
  }

  static Future<Command> _claude(String text, String key) async {
    final r = await http
        .post(
          Uri.parse('https://api.anthropic.com/v1/messages'),
          headers: {
            'x-api-key': key,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
          body: jsonEncode({
            'model': 'claude-haiku-5-5',
            'max_tokens': 300,
            'system': _system,
            'messages': [
              {'role': 'user', 'content': text}
            ],
          }),
        )
        .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) throw Exception('API ${r.statusCode}');
    final out = (jsonDecode(utf8.decode(r.bodyBytes))['content'][0]['text'] as String)
        .replaceAll(RegExp(r'```(json)?'), '')
        .trim();
    final j = jsonDecode(out) as Map<String, dynamic>;
    if (j['action'] == 'whatsapp') {
      return Command('whatsapp', contact: j['contact'], message: j['message']);
    }
    return Command('reply', reply: j['text']?.toString());
  }

  /// Offline fallback: "message revanth I'm late", "send message to revanth saying hi".
  static Command _local(String t) {
    final m = RegExp(
      r'^(?:send\s+(?:a\s+)?(?:whatsapp\s+)?(?:message|msg)|message|msg|text|whatsapp)\s+(?:to\s+)?(\w+)\s+(?:on\s+whatsapp\s+)?(?:saying\s+|that\s+|say\s+)?(.+)$',
      caseSensitive: false,
    ).firstMatch(t.trim());
    if (m != null) return Command('whatsapp', contact: m.group(1), message: m.group(2));
    return Command('reply',
        reply: 'Sorry, offline I only understand: message, a name, then the text.');
  }
}
