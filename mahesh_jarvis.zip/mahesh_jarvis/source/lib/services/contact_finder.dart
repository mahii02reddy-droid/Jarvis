import 'package:flutter_contacts/flutter_contacts.dart';
import 'settings.dart';

class FoundContact {
  final String name, number;
  FoundContact(this.name, this.number);
}

class ContactFinder {
  static Future<FoundContact?> find(String spoken) async {
    if (!await FlutterContacts.requestPermission(readonly: true)) return null;
    final all = await FlutterContacts.getContacts(withProperties: true);
    final q = spoken.toLowerCase().trim();
    Contact? best;
    double bestScore = 0;
    for (final c in all) {
      if (c.phones.isEmpty) continue;
      final name = c.displayName.toLowerCase();
      double s = 0;
      if (name == q) {
        s = 1;
      } else if (name.split(' ').contains(q)) {
        s = 0.9;
      } else if (name.contains(q)) {
        s = 0.75;
      } else {
        for (final tok in name.split(' ')) {
          if (tok.isEmpty) continue;
          final longest = tok.length > q.length ? tok.length : q.length;
          final sim = (1 - _lev(tok, q) / longest) * 0.85;
          if (sim > s) s = sim;
        }
      }
      if (s > bestScore) {
        bestScore = s;
        best = c;
      }
    }
    if (best == null || bestScore < 0.55) return null;
    return FoundContact(best.displayName, _normalise(best.phones.first.number));
  }

  static String _normalise(String raw) {
    var d = raw.replaceAll(RegExp(r'\D'), '');
    if (d.startsWith('0')) d = d.substring(1);
    if (d.length == 10) d = Settings.i.str('cc', '91') + d;
    return d;
  }

  static int _lev(String a, String b) {
    final dp = List.generate(a.length + 1, (_) => List<int>.filled(b.length + 1, 0));
    for (var i = 0; i <= a.length; i++) {
      dp[i][0] = i;
    }
    for (var j = 0; j <= b.length; j++) {
      dp[0][j] = j;
    }
    for (var i = 1; i <= a.length; i++) {
      for (var j = 1; j <= b.length; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = [dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost]
            .reduce((x, y) => x < y ? x : y);
      }
    }
    return dp[a.length][b.length];
  }
}
