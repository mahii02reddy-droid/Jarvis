import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_voice_processor/flutter_voice_processor.dart';
import 'package:porcupine_flutter/porcupine.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'ai_parser.dart';
import 'contact_finder.dart';
import 'native.dart';
import 'settings.dart';

/// Flow: mic frames -> Porcupine ("Jarvis") -> beep ->
/// speech-to-text -> Claude parses -> contact lookup -> WhatsApp send.
class VoicePipeline {
  VoicePipeline._();
  static final VoicePipeline i = VoicePipeline._();

  final status = ValueNotifier<String>('Stopped');
  final logs = ValueNotifier<List<String>>([]);
  bool running = false;

  final _vp = VoiceProcessor.instance!;
  final _stt = SpeechToText();
  final _tts = FlutterTts();
  Porcupine? _pv;
  bool _sttReady = false, _busy = false, _listenerAdded = false;
  int _after = -1; // samples collected after wake word, -1 = idle
  final List<int> _ring = [];
  static const _ringMax = 16000 * 2; // last 2 s of audio

  void _log(String m) {
    final t = DateTime.now().toString().substring(11, 19);
    logs.value = ['$t  $m', ...logs.value].take(60).toList();
  }

  Future<bool> start() async {
    final s = Settings.i;
    final key = s.str('pico');
    if (key.isEmpty) {
      _log('Add your Picovoice AccessKey in Setup');
      return false;
    }
    if (!await _vp.hasRecordAudioPermission()) {
      _log('Microphone permission missing (Setup)');
      return false;
    }
    try {
      await _tts.awaitSpeakCompletion(true);
      _pv = await Porcupine.fromBuiltInKeywords(
        key,
        [BuiltInKeyword.JARVIS],
        sensitivities: [0.7],
      );
      await Native.startService();
      if (!_listenerAdded) {
        _vp.addFrameListener(_onFrame);
        _vp.addErrorListener((e) => _log('Mic error: ${e.message}'));
        _listenerAdded = true;
      }
      await _vp.start(_pv!.frameLength, _pv!.sampleRate);
      running = true;
      status.value = 'Listening for "Jarvis"';
      _log('Started');
      return true;
    } catch (e) {
      _log('Start failed: $e');
      return false;
    }
  }

  Future<void> stop() async {
    running = false;
    try {
      await _vp.stop();
      await _pv?.delete();
    } catch (_) {}
    _pv = null;
    await Native.stopService();
    status.value = 'Stopped';
    _log('Stopped');
  }

  Future<void> _onFrame(List<int> f) async {
    if (_busy || _pv == null) return;
    _ring.addAll(f);
    if (_ring.length > _ringMax) _ring.removeRange(0, _ring.length - _ringMax);

    if (_after >= 0) {
      _after += f.length;
      if (_after >= 16000) {
        // 1 s of extra audio collected after the wake word
        _after = -1;
        _busy = true;
        unawaited(_handle());
      }
      return;
    }
    try {
      if (await _pv!.process(f) >= 0) {
        _log('Wake word heard');
        _after = 0;
      }
    } catch (e) {
      _log('Wake error: $e');
    }
  }

  Future<void> _handle() async {
    try {
      await _vp.stop(); // free the mic for speech recognition
      status.value = 'Yes? Speak now';
      await Native.beep();
      final text = await _listen();
      _log('Heard: "$text"');
      if (text.trim().isEmpty) {
        await _say("Sorry, I didn't catch that");
        return;
      }
      status.value = 'Working…';
      await _execute(text);
    } catch (e) {
      _log('Error: $e');
    } finally {
      _ring.clear();
      _busy = false;
      if (running && _pv != null) {
        try {
          await _vp.start(_pv!.frameLength, _pv!.sampleRate);
          status.value = 'Listening for "Jarvis"';
        } catch (e) {
          _log('Could not resume mic: $e');
        }
      }
    }
  }

  Future<String> _listen() async {
    if (!_sttReady) {
      _sttReady = await _stt.initialize(onError: (e) => _log('Speech: ${e.errorMsg}'));
    }
    if (!_sttReady) return '';
    final done = Completer<String>();
    var last = '';
    await _stt.listen(
      onResult: (r) {
        last = r.recognizedWords;
        if (r.finalResult && !done.isCompleted) done.complete(last);
      },
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 3),
      localeId: Settings.i.str('locale', 'en_IN'),
    );
    return done.future.timeout(const Duration(seconds: 18), onTimeout: () {
      _stt.stop();
      return last;
    });
  }

  Future<void> _execute(String text) async {
    final cmd = await AiParser.parse(text);
    if (cmd.action != 'whatsapp' || cmd.contact == null || cmd.message == null) {
      await _say(cmd.reply ?? 'Sorry, I can only send WhatsApp messages for now');
      return;
    }
    final c = await ContactFinder.find(cmd.contact!);
    if (c == null) {
      await _say("I couldn't find ${cmd.contact} in your contacts");
      return;
    }
    if (await Native.isLocked()) {
      await _say('Phone is locked. Please unlock to send');
      var waited = 0;
      while (await Native.isLocked() && waited < 30) {
        await Future.delayed(const Duration(seconds: 1));
        waited++;
      }
      if (await Native.isLocked()) {
        await _say('Cancelled, the phone stayed locked');
        return;
      }
    }
    _log('Sending to ${c.name} (${c.number}): ${cmd.message}');
    if (!await Native.openWhatsApp(c.number, cmd.message!)) {
      await _say('Please turn on Accessibility for Jarvis in Setup');
      return;
    }
    for (var i = 0; i < 15; i++) {
      await Future.delayed(const Duration(seconds: 1));
      if (await Native.consumeSent()) {
        await _say('Message sent to ${c.name}');
        return;
      }
    }
    await _say('I opened the chat but could not press send');
  }

  Future<void> _say(String t) async {
    _log('Jarvis: $t');
    status.value = t;
    await _tts.speak(t);
  }
}
