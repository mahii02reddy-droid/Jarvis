Put your built file here and name it exactly:  mahesh-jarvis.apk
Then drag this whole folder onto https://app.netlify.com/drop
