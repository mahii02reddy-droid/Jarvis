#!/usr/bin/env bash
set -e
echo "=== Building Mahesh's Jarvis ==="
flutter create --org com.mahesh --project-name jarvis --platforms android app
cp -r source/lib/. app/lib/
cp source/pubspec.yaml app/pubspec.yaml
cp -r source/android_overlay/app/. app/android/app/
rm -rf app/android/app/src/main/kotlin
cd app && flutter pub get
echo "Done. Connect your CMF phone (USB debugging ON) and run:  flutter run --release"
