# Mahesh's Jarvis (Android, Flutter + Java)

Say **"Jarvis"**, pause, then speak: *"message Revanth I will be late"*.
It checks it is **your voice**, finds the contact, opens WhatsApp and taps Send. Works with the screen off.

## 1. Get the keys
- **Picovoice AccessKey** (free): console.picovoice.ai - used for wake word (Porcupine) and your-voice-only check (Eagle).
- **Claude API key** (optional): console.anthropic.com - understands Hindi/Telugu/mixed commands. Without it, offline rules handle: `message <name> <text>`.

## 2. Build
Install Flutter + Android SDK, then in this folder:
- Windows: `setup.bat`
- Mac/Linux: `./setup.sh`

Plug in the CMF Phone 2 Pro (Developer options -> USB debugging) and run `cd app` then `flutter run --release`.

## 3. First-time setup inside the app (gear icon)
1. Paste the Picovoice key (and Claude key).
2. Grant: Microphone, Contacts, Notifications.
3. **Accessibility**: if the toggle is greyed out, open Settings -> Apps -> Mahesh's Jarvis -> three dots -> *Allow restricted settings*, then enable it.
4. **Display over other apps** ON, **Battery -> Unrestricted** ON.
5. Tap **Record my voice** and talk for ~30 s.
6. Go back, tap the mic circle to start. Lock the app in Recents (do not swipe it away).

## Using it
- The wake word is **"Jarvis"** (Porcupine built-in). For exactly "Hey Jarvis", train a custom keyword on the Picovoice console and swap it in `voice_pipeline.dart` (`Porcupine.fromKeywordPaths`).
- Pause about 1 second after "Jarvis" until you hear the beep, then speak the command.
- Phone locked with a PIN: Jarvis says "unlock to send" and continues once you unlock. Use Smart Lock (on-body / trusted place) to avoid that.

## Known limits
- After a phone reboot, open the app once and tap start (Android 15 microphone rule).
- Sending depends on WhatsApp's Send button; a big WhatsApp redesign may need a small fix in `JarvisAccessibilityService.java`.
- Plugin APIs (Eagle/Porcupine) change between versions. If `flutter run` reports a mismatch in `voice_pipeline.dart` or `setup_screen.dart`, adjust to the version's docs.
