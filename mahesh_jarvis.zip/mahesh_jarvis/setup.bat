@echo off
echo === Building Mahesh's Jarvis ===
flutter create --org com.mahesh --project-name jarvis --platforms android app || goto :err
xcopy /E /I /Y source\lib app\lib >nul
copy /Y source\pubspec.yaml app\pubspec.yaml >nul
xcopy /E /I /Y source\android_overlay\app app\android\app >nul
if exist app\android\app\src\main\kotlin rmdir /S /Q app\android\app\src\main\kotlin
cd app
flutter pub get || goto :err
echo.
echo Done. Connect your CMF phone (USB debugging ON) and run:  flutter run --release
goto :eof
:err
echo Something failed - see the message above.
